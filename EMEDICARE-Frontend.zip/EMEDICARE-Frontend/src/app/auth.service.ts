import { Injectable } from "@angular/core";
import { NavigationService } from "./navigation.service";


@Injectable({
    providedIn: 'root'
  })
  export class AuthService {
    constructor(private navigationService: NavigationService) {}
  
    login() {
      
      this.navigationService.setLoggedIn(true);
    }
  
    logout() {
      this.navigationService.setLoggedIn(false);
    }
  }
  
export class Product{
    pid:number=0;
    pname:string="";
    price:number=0;
    pqty:number;
    ptype:string;
    status:string;
    
}
export class Cart {

        id:number;
        lid:number;
        pid:number;
        booked:string;
        pname:string;
        price:number;
        ptype:string;
    
}

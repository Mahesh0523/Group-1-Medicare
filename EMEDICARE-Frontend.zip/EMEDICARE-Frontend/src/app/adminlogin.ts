export class Userlogin {

   id : string;
   email :string;
    password : string;
}

package com.medicare.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicare.project.beans.Cart;
import com.medicare.project.beans.Product;
import com.medicare.project.service.CartService;
import com.medicare.project.service.ProductService;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/cart")
public class CartController {

	@Autowired
	CartService cservice;

	//http://localhost:8686/cart/cartlist
	@GetMapping("/cartlist")
	public List listAllPrdinCart() {
		return cservice.listAllPrdinCart();
	}
	
	//http://localhost:8686/cart/cartlistbyloginsid
	@GetMapping("/cartlistbyloginsid/{id}")
	public List cartlistbyloginsid(@PathVariable("id") int id) {
		return cservice.cartlistbyloginsid(id);
	}
	
	//http://localhost:8686/cart/addToCart
	@PostMapping("/addToCart")
	public int addToCart(@RequestBody Cart cart) {
		return cservice.addToCart(cart);
	}
	
	//http://localhost:8686/cart/sumofproduct
	@GetMapping("/sumofproduct/{id}")
	public List sumofproduct(@PathVariable("id") int id) {
		return cservice.sumofproduct(id);
	}
	

	//http://localhost:8686/cart/bookedProducts/
	@GetMapping("/bookedProducts/{id}")
	public List<Cart> bookedProducts(@PathVariable("id") int id) {
		return cservice.bookedProducts(id);
	}
	
	//http://localhost:8686/cart/makebooking/
	@PutMapping("/makebooking/{id}")
	public List makebooking(@PathVariable("id") int id) {
	return cservice.makebooking(id);
	}
	
	
	//http://localhost:8686/cart/delProductfromCart/{pid}
	@DeleteMapping("/delProductfromCart/{pid}")
	public List delProductfromCart(@PathVariable("pid") int pid) {
		return cservice.delProductfromCart(pid);
	}
	
		//http://localhost:8686/cart/search/
	@GetMapping("/search/{name}")
	public List search(@PathVariable("name") String name) {
		return cservice.search(name);
	}
	

	
	
}

package com.medicare.project.service;

import java.util.List;

import com.medicare.project.beans.Login;



public interface LoginService {
	
	public abstract int Register(Login login);
	
	public abstract Login LoginUser(String email,String password);

	public abstract List<Login> getUser();
	
	public abstract List<Login> getUserProfile(int id);
	
	public abstract void UpdateProfile(int Id,Login login);


}

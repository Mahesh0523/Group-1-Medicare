package com.medicare.project.dao;

import java.util.Iterator;
import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestMapping;

import com.medicare.project.beans.Cart;
import com.medicare.project.beans.Login;
import com.medicare.project.beans.Product;

@Repository
public class CartDaoImpl implements CartDao {


	@PersistenceContext
	private EntityManager em;
	
	//adding to cart
		@Transactional
		@Override
		public int addToCart(Cart cart) {
			em.persist(cart);
			return cart.getId();
		}	
	
	//list of all products
	@Transactional
	@Override
	public List listAllPrdinCart() {
		String sql="Select t from Cart t ";
		Query qry=em.createQuery(sql);
		List ProductList=qry.getResultList();
		return ProductList;
		
	}
	
	@Transactional
	@Override
	public List delProductfromCart(int id) {
		
		Cart t = em.find(Cart.class, id);
		em.remove(t);
		String sql="Select t from Cart t ";
		Query qry=em.createQuery(sql);
		List ProductList=qry.getResultList();
		return ProductList;
		
	}	
	
	@Transactional
	@Override
	public List cartlistbyloginsid(int id) {
		Query qry = em.createQuery("Select p from Cart p where p.lid=:id and booked='UnderProcess'");
		qry.setParameter("id",id);
		List ProductList =qry.getResultList();
		System.out.println(ProductList);
		return ProductList;
	}

	

	@Transactional
	@Override
	public List sumofproduct(int id) {
		Query qry = em.createQuery("Select sum(price) from Cart c where c.lid=:id and booked='UnderProcess'"); 
		qry.setParameter("id",id);
		List Sum = qry.getResultList();
		System.out.println(qry.getResultList());
		return Sum;
		
	}

	
	@Modifying
	@Transactional
	@Override
	public List makebooking(int id) {
		
		Query qry = em.createQuery("Update Cart c set c.booked='confirmed' where lid=:id"); 
		qry.setParameter("id",id);
		qry.executeUpdate();
		String sql="Select t from Cart t ";
		Query qry1=em.createQuery(sql);
		List ProductList=qry1.getResultList();
		return ProductList;
		
		
	}

	
	@Transactional
	@Override
	public List bookedProducts(int id) {
		Query qry = em.createQuery("select c from Cart c where c.lid=:id and c.booked='confirmed'");
		qry.setParameter("id",id);
		List Sum = qry.getResultList();
		System.out.println(Sum);
		return Sum;
		
	}

	
	    @Transactional
		@Override
		public List search(String name) {
			Query qry = em.createQuery("select c from Product c where c.pname like :name");
		    qry.setParameter("name", "%" + name + "%");
			List ProductList=qry.getResultList();
			return ProductList;
		}

		
}

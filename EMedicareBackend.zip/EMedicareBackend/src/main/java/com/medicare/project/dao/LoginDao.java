package com.medicare.project.dao;

import java.util.List;

import com.medicare.project.beans.Login;
import com.medicare.project.beans.Register;

public interface LoginDao {



	int Register(Login login);
	
	public Login LoginUser(String email, String password);
	

	List<Login> getUserProfile(int id);
	
	List<Login> getUser();

	void UpdateProfile(int Id,Login login);
	
	
	

}

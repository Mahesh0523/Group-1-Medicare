package com.medicare.project.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.medicare.project.beans.Product;
import com.medicare.project.service.ProductService;
import com.medicare.project.service.ProductServiceImpl;



@SpringBootTest
class ProductTest{

	
	
	@Autowired
	ProductService ps;
	
	@Autowired
	ProductServiceImpl pl;
	
	
	

	@Test
	@DisplayName("GET All Products")
	public void getallproductTest(){

	  List<Product> ks = ps.listAllPrd();
	 double rs =ks.size();
	 assertTrue(rs>0);

	}
	@Test
	@DisplayName("UPDATE ")
	public void updatemedicinedetails() {
		Product pd =new Product();
		pd.setPid(7);
		pd.setPname("aspirin");
		pd.setPqty(9);
		pd.setPtype("Antibiotic");
		pd.setPrice(88);
		pd.setStatus("A");
		pl.editProduct(7, pd);
		assertEquals(pd.getPrice(),88);				
		
	}

	@Test
	@DisplayName("Insert Operation")
	public void Productinsert() {
		Product pd =new Product();
		pd.setPname("dolo35");
		pd.setPqty(8);
		pd.setPtype("Antipyretics");
		pd.setPrice(30);
		pd.setStatus("A");
		pl.addProduct(pd);
		assertTrue(pd.getPid()>0);
		
	}
	
	@Test
	@DisplayName("Delete Product")
	public void deletemedicine() {
		int productIdToDelete = 2;
	    ps.delProduct(productIdToDelete);
	    
	    List<Product> remainingProducts = ps.listAllPrd(); 
	    
	    boolean productFound = false;
	    for (Product product : remainingProducts) {
	        if (product.getPid() == productIdToDelete) {
	            productFound = true;
	            break;
	            }
	    }
	    
	    assertFalse(productFound, "Product with ID " + productIdToDelete + " should have been deleted");
	}
}
